using System;
using System.Collections.Generic;
using SingedTerra.Encounter;

namespace SingedTerra.LastStand
{
    public sealed partial class LastStandProgression
    {
        const int CurrentSaveVersion=8;
        static Dictionary<string,object> Map(params object[] entries)
        {
            var result=new Dictionary<string,object>(StringComparer.Ordinal);
            for(int n=0;n<entries.Length;n+=2)result.Add((string)entries[n],entries[n+1]);
            return result;
        }
        static int Number(Dictionary<string,object> map,string key)=>LastStandSaveJson.Integer(map[key]);
        static string Text(Dictionary<string,object> map,string key)=>LastStandSaveJson.String(map[key]);
        static bool Bool(Dictionary<string,object> map,string key)=>LastStandSaveJson.Boolean(map[key]);
        static Dictionary<string,object> LevelsJson(IReadOnlyList<int> levels,string economy=null)
        {
            var result=Map();
            foreach(var track in LastStandUpgradeCatalog.ForEconomy(economy??LastStandUpgradeCatalog.EconomyVersion).Tracks)result.Add(track.Key,levels[(int)track.Id]);
            return result;
        }
        static int[] ReadLevels(object value,bool permanent,string economy=null)
        {
            var map=LastStandSaveJson.Object(value);
            var catalog=LastStandUpgradeCatalog.ForEconomy(economy??LastStandUpgradeCatalog.EconomyVersion);
            if(map.Count!=catalog.Tracks.Count)throw new FormatException("Missing upgrade tracks.");
            var result=new int[map.Count];
            foreach(var pair in map)
            {
                if(!catalog.TryGet(pair.Key,out var definition))throw new FormatException("Unknown upgrade track.");
                int level=LastStandSaveJson.Integer(pair.Value);
                if(level>(permanent?definition.PermanentCap:definition.TotalCap)||!definition.Available&&level!=0)throw new FormatException("Invalid upgrade level.");
                result[(int)definition.Id]=level;
            }
            return result;
        }
        static List<object> Strings(IEnumerable<string> values)
        {
            var sorted=new List<string>(values);sorted.Sort(StringComparer.Ordinal);
            var result=new List<object>();foreach(string s in sorted)result.Add(s);return result;
        }
        static HashSet<string> ReadStrings(object value)
        {
            var result=new HashSet<string>(StringComparer.Ordinal);
            foreach(var item in LastStandSaveJson.Array(value))
                if(!result.Add(LastStandSaveJson.String(item)))throw new FormatException("Duplicate saved identity.");
            return result;
        }
        static object PendingJson(PendingDefeat p)=>p==null?null:Map(
            "runId",p.RunId,"elapsedTicks",p.ElapsedTicks,"kills",p.Kills,"reward",p.Reward,
            "tier",p.Tier,"profileVersion",p.ProfileVersion,"isLimit",p.IsLimit,
            "newBestTime",p.NewBestTime,"newBestKills",p.NewBestKills,"unlockedTierTwo",p.UnlockedTierTwo);
        static object AppearanceJson(LastStandTankAppearance appearance)=>Map(
            "treads",appearance.Treads,"hull",appearance.Hull,"turret",appearance.Turret,
            "barrel",appearance.Barrel,"paint",appearance.Paint);
        static LastStandTankAppearance ReadAppearance(object value)
        {
            var map=LastStandSaveJson.Object(value);
            LastStandSaveJson.Fields(map,"treads","hull","turret","barrel","paint");
            if(!LastStandTankAppearance.TryCreate(Text(map,"treads"),Text(map,"hull"),Text(map,"turret"),
                Text(map,"barrel"),Text(map,"paint"),out var appearance))throw new FormatException("Unknown cosmetic identity.");
            return appearance;
        }
        static object LoadoutJson(LastStandLoadout loadout)=>Map("primary",loadout.PrimaryId,"secondary",loadout.SecondaryId);
        static LastStandLoadout ReadLoadout(object value)
        {
            var map=LastStandSaveJson.Object(value);LastStandSaveJson.Fields(map,"primary","secondary");
            return new LastStandLoadout(Text(map,"primary"),map["secondary"]==null?null:Text(map,"secondary"));
        }
        static object CombatResearchJson(LastStandCombatResearchSnapshot research)=>Map("armorPiercing",research.ArmorPiercing,
            "areaControl",research.AreaControl,"fieldEngineering",research.FieldEngineering);
        static LastStandCombatResearchSnapshot ReadCombatResearch(object value)
        {
            var map=LastStandSaveJson.Object(value);LastStandSaveJson.Fields(map,"armorPiercing","areaControl","fieldEngineering");
            return new LastStandCombatResearchSnapshot(Number(map,"armorPiercing"),Number(map,"areaControl"),Number(map,"fieldEngineering"));
        }
        static object PresetsJson(IReadOnlyList<LastStandLoadoutPreset> presets)
        {
            var result=new List<object>();foreach(var preset in presets)
                result.Add(preset==null?null:Map("name",preset.Name,"loadout",LoadoutJson(preset.Loadout)));
            return result;
        }
        static LastStandLoadoutPreset[] ReadPresets(object value)
        {
            var rows=LastStandSaveJson.Array(value);
            if(rows.Count!=LastStandLoadoutPreset.MaximumPresets)throw new FormatException("Invalid preset slot count.");
            var result=new LastStandLoadoutPreset[rows.Count];for(int n=0;n<rows.Count;n++)if(rows[n]!=null){
                var row=LastStandSaveJson.Object(rows[n]);LastStandSaveJson.Fields(row,"name","loadout");
                result[n]=new LastStandLoadoutPreset(Text(row,"name"),ReadLoadout(row["loadout"]));
            }
            return result;
        }
        static string Serialize(Record record)
        {
            var tiers=Map();
            foreach(var tier in LastStandTierCatalog.All)
            {
                var row=record.Tiers[tier.Key];
                tiers.Add(tier.Key,Map("bestWave",row.BestWave,"legacyTicks",row.LegacyTicks,
                    "legacyKills",row.LegacyKills,"unlocked",row.Unlocked));
            }
            return LastStandSaveJson.Write(Map("version",CurrentSaveVersion,"credits",record.Wallet,
                "revision",record.Revision,"recoveryRemainder",record.RecoveryRemainder,
                "appearance",AppearanceJson(record.Appearance),
                "research",ResearchJson(record.Research),"history",HistoryJson(record.History),
                "permanentLevels",LevelsJson(record.Levels),"nextRunId",record.NextRunId,
                "lastFinalizedRunId",record.FinalizedRunId,"selectedTier",record.SelectedTier,
                "selectedFitting",record.SelectedFitting,"tierRecords",tiers,
                "secondaryFitting",record.SecondaryFitting,"loadoutPresets",PresetsJson(record.Presets),
                "firstClears",Strings(record.FirstClears),"unlockedFittings",Strings(record.Fittings),
                "pendingDefeat",PendingJson(record.Pending),"checkpoint",CheckpointJson(record.Checkpoint)));
        }
        static bool TryParseSave(string raw,out Record record,out bool migrate)
        {
            record=null;migrate=false;
            try
            {
                var map=LastStandSaveJson.Read(raw);
                if(!map.ContainsKey("version"))return false;
                int version=Number(map,"version");
                if(version<4)
                {
                    if(!TryParseLegacyVersions(raw,out record,out migrate))return false;
                    InitializeTiers(record,true);migrate=true;return true;
                }
                if(version<4 || version>CurrentSaveVersion)return false;
                var fields=new List<string>{"version","credits","permanentLevels","nextRunId","lastFinalizedRunId",
                    "selectedTier","selectedFitting","tierRecords","firstClears","unlockedFittings","pendingDefeat","checkpoint"};
                if(version>=5)fields.AddRange(new[]{"revision","recoveryRemainder","research","history"});
                if(version>=7)fields.Add("appearance");
                if(version>=8)fields.AddRange(new[]{"secondaryFitting","loadoutPresets"});
                LastStandSaveJson.Fields(map,fields.ToArray());
                var levels=ReadLevels(map["permanentLevels"],true,version==4?LastStandUpgradeCatalog.LegacyEconomyVersion:
                    version==5?LastStandUpgradeCatalog.RetainedEconomyVersion:version<8?LastStandUpgradeCatalog.CombatDepthEconomyVersion:LastStandUpgradeCatalog.EconomyVersion);
                var tiers=version<6?LastStandTierCatalog.Legacy:version<8?LastStandTierCatalog.CombatDepth:LastStandTierCatalog.All;
                var fittings=version<6?LastStandFittingCatalog.Legacy:version<8?LastStandFittingCatalog.CombatDepth:LastStandFittingCatalog.Definitions;
                var parsed=new Record { Wallet=Number(map,"credits"),Levels=levels,
                    NextRunId=Number(map,"nextRunId"),FinalizedRunId=Number(map,"lastFinalizedRunId"),
                    SelectedTier=Number(map,"selectedTier"),SelectedFitting=Text(map,"selectedFitting"),
                    FirstClears=ReadStrings(map["firstClears"]),Fittings=ReadStrings(map["unlockedFittings"]) };
                if(version>=7)parsed.Appearance=ReadAppearance(map["appearance"]);
                if(version>=8){
                    parsed.SecondaryFitting=map["secondaryFitting"]==null?null:Text(map,"secondaryFitting");
                    parsed.Presets=ReadPresets(map["loadoutPresets"]);
                }
                if(parsed.NextRunId<1 || parsed.FinalizedRunId>=parsed.NextRunId || !LastStandTierCatalog.IsValid(parsed.SelectedTier)||version<6&&parsed.SelectedTier>2)return false;
                var tierMap=LastStandSaveJson.Object(map["tierRecords"]);
                if(tierMap.Count!=tiers.Count)return false;
                var knownMilestones=new HashSet<string>(StringComparer.Ordinal);
                foreach(var tier in tiers)
                {
                    var t=LastStandSaveJson.Object(tierMap[tier.Key]);
                    LastStandSaveJson.Fields(t,"bestWave","legacyTicks","legacyKills","unlocked");
                    var row=new TierRecord { BestWave=Number(t,"bestWave"),LegacyTicks=Number(t,"legacyTicks"),
                        LegacyKills=Number(t,"legacyKills"),Unlocked=Bool(t,"unlocked") };
                    if(row.LegacyTicks>LastStandTierCatalog.LegacyHorizonTicks || !tier.Playable&&(row.Unlocked||row.BestWave>0) ||
                        !row.Unlocked && (tier.RequiredTier==0 || row.BestWave>0 || row.LegacyTicks>0 || row.LegacyKills>0))return false;
                    parsed.Tiers.Add(tier.Key,row);
                    foreach(var milestone in LastStandRewardCatalog.Milestones(tier,tiers,fittings,version>=8))
                    {
                        knownMilestones.Add(milestone.Id);
                        bool earned=parsed.FirstClears.Contains(milestone.Id);
                        if(earned!=(row.BestWave>=milestone.Wave))return false;
                    }
                }
                foreach(string id in parsed.FirstClears)if(!knownMilestones.Contains(id))return false;
                foreach(string id in parsed.Fittings) {
                    LastStandFittingDefinition known=null;foreach(var fitting in fittings)if(fitting.Id==id){known=fitting;break;}
                    if(known==null||!known.Playable||!known.InitiallyUnlocked&&parsed.Tiers[LastStandTierCatalog.Get(known.UnlockTier).Key].BestWave<known.UnlockWave)return false;
                }
                if(!parsed.Fittings.Contains("repair") || !parsed.Fittings.Contains("launcher") ||
                    !parsed.Fittings.Contains(parsed.SelectedFitting) || !parsed.Tiers[LastStandTierCatalog.Get(parsed.SelectedTier).Key].Unlocked)return false;
                var loadout=new LastStandLoadout(parsed.SelectedFitting,parsed.SecondaryFitting);
                if(!loadout.IsAvailable(Entitlements(parsed).EquipmentBays,parsed.Fittings.Contains))return false;
                foreach(var preset in parsed.Presets)if(preset!=null&&
                    !preset.Loadout.IsAvailable(Entitlements(parsed).EquipmentBays,parsed.Fittings.Contains))return false;
                bool scatterEarned=parsed.FirstClears.Contains(LastStandTierCatalog.Get(1).Key+":wave-100");
                if(parsed.Fittings.Contains("scattergun")!=scatterEarned)return false;
                foreach(var tier in tiers)
                    if(tier.RequiredTier!=0 && parsed.Tiers[LastStandTierCatalog.Get(tier.RequiredTier).Key].BestWave>=tier.RequiredWave &&
                        !parsed.Tiers[tier.Key].Unlocked && tier.Id<=2)return false;
                parsed.Pending=ReadPending(map["pendingDefeat"],parsed);
                parsed.Checkpoint=ReadCheckpoint(map["checkpoint"],version);
                if(parsed.Checkpoint!=null)
                {
                    var cp=parsed.Checkpoint;
                    if(parsed.Pending!=null || cp.RunId!=parsed.NextRunId-1 || cp.RunId<=parsed.FinalizedRunId ||
                        cp.Tier!=parsed.SelectedTier || version<8&&cp.FittingId!=parsed.SelectedFitting || cp.Encounter.Hull==0 ||
                        cp.CompletedWave>parsed.Tiers[LastStandTierCatalog.Get(cp.Tier).Key].BestWave||
                        !cp.Loadout.IsAvailable(Entitlements(parsed).EquipmentBays,parsed.Fittings.Contains))return false;
                    foreach(var track in LastStandUpgradeCatalog.ForEconomy(cp.Shop.EconomyVersion).Tracks)
                        if(cp.Shop.PermanentLevels[(int)track.Id]>parsed.Levels[(int)track.Id])return false;
                }
                if(version>=5)
                {
                    parsed.Revision=LastStandSaveJson.LongInteger(map["revision"]);
                    parsed.RecoveryRemainder=Number(map,"recoveryRemainder");
                    if(parsed.Revision<1 || parsed.RecoveryRemainder>=LastStandResearchCatalog.MultiplierDenominator)return false;
                    parsed.Research=ReadResearch(map["research"]);parsed.History=ReadHistory(map["history"]);
                    if(!parsed.Research.IsAvailableFor(parsed.Tiers[LastStandTierCatalog.Get(1).Key].BestWave,
                        parsed.Tiers[LastStandTierCatalog.Get(2).Key].BestWave)||
                        parsed.Checkpoint!=null&&!ResearchSnapshotIsFunded(parsed.Research,parsed.Checkpoint.CombatResearch))return false;
                    var history=parsed.History.Snapshot();var current=history.Current;
                    if(history.LastFinalizedRunId!=parsed.FinalizedRunId || (current==null)!=(parsed.Checkpoint==null))return false;
                    if(current!=null && (current.RunId!=parsed.Checkpoint.RunId || current.Tier!=parsed.Checkpoint.Tier ||
                        current.Fitting!=(parsed.Checkpoint.Edition.IsBuildcraft?parsed.Checkpoint.Loadout.ToString():parsed.Checkpoint.FittingId) || current.EconomyVersion!=parsed.Checkpoint.Shop.EconomyVersion ||
                        current.HighestClearedWave!=parsed.Checkpoint.CompletedWave))return false;
                }
                migrate=version<CurrentSaveVersion;
                record=parsed;return true;
            }
            catch(Exception error) when(error is FormatException || error is ArgumentException || error is KeyNotFoundException ||
                error is OverflowException || error is InvalidOperationException || error is IndexOutOfRangeException)
            { return false; }
        }
        static PendingDefeat ReadPending(object value,Record record)
        {
            if(value==null)return null;
            var p=LastStandSaveJson.Object(value);
            LastStandSaveJson.Fields(p,"runId","elapsedTicks","kills","reward","tier","profileVersion","isLimit","newBestTime","newBestKills","unlockedTierTwo");
            int run=Number(p,"runId"),ticks=Number(p,"elapsedTicks"),kills=Number(p,"kills"),reward=Number(p,"reward"),tier=Number(p,"tier");
            string version=Text(p,"profileVersion");bool limit=Bool(p,"isLimit"),time=Bool(p,"newBestTime"),bestKills=Bool(p,"newBestKills"),unlock=Bool(p,"unlockedTierTwo");
            if(run<1 || run!=record.NextRunId-1 || run<=record.FinalizedRunId)throw new FormatException("Invalid legacy claim identity.");
            if(tier==0)
            {
                if(version!="" || reward!=1 || limit || time || bestKills || unlock)throw new FormatException("Invalid legacy claim.");
            }
            else
            {
                if(!LastStandTierCatalog.IsValid(tier) || tier!=record.SelectedTier || version!=LastStandTierCatalog.LegacyProfileVersion ||
                    ticks>LastStandTierCatalog.LegacyHorizonTicks || reward!=(limit?0:1) || limit && ticks!=LastStandTierCatalog.LegacyHorizonTicks)
                    throw new FormatException("Invalid legacy result.");
                var row=record.Tiers[LastStandTierCatalog.Get(tier).Key];
                if(!row.Unlocked || row.LegacyTicks<ticks || row.LegacyKills<kills ||
                    time && (row.LegacyTicks!=ticks || ticks==0) || bestKills && (row.LegacyKills!=kills || kills==0) ||
                    unlock && (tier!=1 || !time || ticks<1200 || !record.Tiers[LastStandTierCatalog.Get(2).Key].Unlocked))
                    throw new FormatException("Legacy result does not match retained history.");
            }
            return new PendingDefeat(run,ticks,kills,reward,tier,version,limit,time,bestKills,unlock);
        }
        static object CheckpointJson(LastStandRunCheckpoint checkpoint)
        {
            if(checkpoint==null)return null;
            var e=checkpoint.Encounter;var s=checkpoint.Shop;
            var result=Map("runId",checkpoint.RunId,"contentVersion",checkpoint.Edition.ContentVersion,"encounter",Map(
                "version",EncounterCheckpoint.Version,"rulesVersion",e.RulesVersion,"tier",e.Tier,"fitting",e.Fitting,
                "wave",e.Wave,"completedWave",e.CompletedWave,"tick",e.Tick,"hull",e.Hull,"maximumHull",e.MaximumHull,
                "spawned",e.Spawned,"kills",e.Kills,"cannonShots",e.CannonShots,"launcherShots",e.LauncherShots,
                "scattergunShots",e.ScattergunShots,"restored",e.Restored,"closeHits",e.CloseHits,"rangedHits",e.RangedHits,
                "nextSpawnTick",e.NextSpawnTick,"nextCannonTick",e.NextCannonTick,"nextLauncherTick",e.NextLauncherTick,
                "nextRepairTick",e.NextRepairTick,"nextScattergunTick",e.NextScattergunTick,"lastCannonShotTick",e.LastCannonShotTick,
                "cannonDamage",e.CannonDamage,"launcherDamage",e.LauncherDamage,"scattergunDamage",e.ScattergunDamage,
                "cannonPeriod",e.CannonPeriod,"repairAmount",e.RepairAmount,"armorLevel",e.ArmorLevel,"committedCannonDamage",e.CommittedCannonDamage),
                "shop",Map("version",s.SchemaVersion==LastStandShopCheckpoint.LegacyVersion?LastStandShopCheckpoint.PreviousVersion:s.SchemaVersion,"economyVersion",s.EconomyVersion,
                    "baseEarnedScrap",s.BaseEarnedScrap,"bonusEarnedScrap",s.BonusEarnedScrap,"incomeRemainder",s.IncomeRemainder,
                    "runId",s.RunId,"fitting",s.Fitting,
                    "purchaseSequence",s.PurchaseSequence,"uniqueKills",s.UniqueKills,"earnedScrap",s.EarnedScrap,
                    "spentScrap",s.SpentScrap,"scrap",s.Scrap,"permanentLevels",LevelsJson(s.PermanentLevels,s.EconomyVersion),"runPurchases",LevelsJson(s.RunPurchases,s.EconomyVersion)));
            if(s.SchemaVersion==LastStandShopCheckpoint.Version){var shop=LastStandSaveJson.Object(result["shop"]);shop.Add("tier",s.Tier);shop.Add("rewardWave",s.RewardWave);shop.Add("defeatedMask",s.DefeatedMask);}
            if(!checkpoint.Edition.IsLegacy){var encounter=LastStandSaveJson.Object(result["encounter"]);
                encounter.Add("mortarShots",e.MortarShots);encounter.Add("railgunShots",e.RailgunShots);
                encounter.Add("nextMortarTick",e.NextMortarTick);encounter.Add("nextRailgunTick",e.NextRailgunTick);
                encounter.Add("mortarDamage",e.MortarDamage);encounter.Add("railgunDamage",e.RailgunDamage);}
            if(checkpoint.Edition.IsBuildcraft){
                result.Add("loadout",LoadoutJson(checkpoint.Loadout));result.Add("combatResearch",CombatResearchJson(checkpoint.CombatResearch));
                var b=e.Buildcraft;result.Add("buildcraft",Map("arcShots",b.ArcShots,"nextArcTick",b.NextArcTick,"arcDamage",b.ArcDamage,
                    "shield",b.Shield,"shieldCapacity",b.ShieldCapacity,"shieldRestored",b.ShieldRestored,"shieldAbsorbed",b.ShieldAbsorbed,
                    "nextShieldRechargeTick",b.NextShieldRechargeTick,"lastShieldHitTick",b.LastShieldHitTick));
            }
            return result;
        }
        static LastStandRunCheckpoint ReadCheckpoint(object value,int profileVersion)
        {
            if(value==null)return null;
            var p=LastStandSaveJson.Object(value);
            var e=LastStandSaveJson.Object(p["encounter"]);var s=LastStandSaveJson.Object(p["shop"]);
            string rules=Text(e,"rulesVersion");bool buildcraft=rules==LastStandRunEdition.CurrentRulesVersion;
            bool current=rules==LastStandRunEdition.CombatDepthRulesVersion||buildcraft;
            if(buildcraft&&profileVersion<8)throw new FormatException("New run requires its profile schema.");
            var checkpointFields=new List<string>{"runId","encounter","shop"};
            if(profileVersion>=6)checkpointFields.Add("contentVersion");
            if(buildcraft)checkpointFields.AddRange(new[]{"loadout","combatResearch","buildcraft"});
            LastStandSaveJson.Fields(p,checkpointFields.ToArray());
            var loadout=buildcraft?ReadLoadout(p["loadout"]):LastStandLoadout.Single((LastStandFitting)Number(e,"fitting"));
            var combatResearch=buildcraft?ReadCombatResearch(p["combatResearch"]):LastStandCombatResearchSnapshot.None;
            LastStandBuildcraftCheckpoint combat=null;
            if(buildcraft){
                var b=LastStandSaveJson.Object(p["buildcraft"]);
                LastStandSaveJson.Fields(b,"arcShots","nextArcTick","arcDamage","shield","shieldCapacity","shieldRestored","shieldAbsorbed","nextShieldRechargeTick","lastShieldHitTick");
                combat=new LastStandBuildcraftCheckpoint(Number(b,"arcShots"),Number(b,"nextArcTick"),Number(b,"arcDamage"),Number(b,"shield"),Number(b,"shieldCapacity"),
                    Number(b,"shieldRestored"),Number(b,"shieldAbsorbed"),Number(b,"nextShieldRechargeTick"),Number(b,"lastShieldHitTick"));
            }
            var encounterFields=new List<string>{"version","rulesVersion","tier","fitting","wave","completedWave","tick","hull","maximumHull",
                "spawned","kills","cannonShots","launcherShots","scattergunShots","restored","closeHits","rangedHits",
                "nextSpawnTick","nextCannonTick","nextLauncherTick","nextRepairTick","nextScattergunTick","lastCannonShotTick",
                "cannonDamage","launcherDamage","scattergunDamage","cannonPeriod","repairAmount","armorLevel","committedCannonDamage"};
            if(current)encounterFields.AddRange(new[]{"mortarShots","railgunShots","nextMortarTick","nextRailgunTick","mortarDamage","railgunDamage"});
            LastStandSaveJson.Fields(e,encounterFields.ToArray());
            int schema=Number(s,"version");
            var shopFields=new List<string>{"version","runId","fitting","purchaseSequence","uniqueKills","earnedScrap","spentScrap","scrap","permanentLevels","runPurchases"};
            if(schema==LastStandShopCheckpoint.PreviousVersion||schema==LastStandShopCheckpoint.Version)shopFields.AddRange(new[]{"economyVersion","baseEarnedScrap","bonusEarnedScrap","incomeRemainder"});
            if(schema==LastStandShopCheckpoint.Version)shopFields.AddRange(new[]{"tier","rewardWave","defeatedMask"});
            LastStandSaveJson.Fields(s,shopFields.ToArray());
            if(Number(e,"version")!=EncounterCheckpoint.Version || schema!=LastStandShopCheckpoint.Version && schema!=LastStandShopCheckpoint.PreviousVersion&&schema!=LastStandShopCheckpoint.LegacyVersion)
                throw new FormatException("Unsupported checkpoint schema.");
            var encounter=new EncounterCheckpoint(Text(e,"rulesVersion"),Number(e,"tier"),Number(e,"fitting"),Number(e,"wave"),Number(e,"completedWave"),Number(e,"tick"),
                Number(e,"hull"),Number(e,"maximumHull"),Number(e,"spawned"),Number(e,"kills"),Number(e,"cannonShots"),Number(e,"launcherShots"),Number(e,"scattergunShots"),
                Number(e,"restored"),Number(e,"closeHits"),Number(e,"rangedHits"),Number(e,"nextSpawnTick"),Number(e,"nextCannonTick"),Number(e,"nextLauncherTick"),
                Number(e,"nextRepairTick"),Number(e,"nextScattergunTick"),Number(e,"lastCannonShotTick"),Number(e,"cannonDamage"),Number(e,"launcherDamage"),
                Number(e,"scattergunDamage"),Number(e,"cannonPeriod"),Number(e,"repairAmount"),Number(e,"armorLevel"),Number(e,"committedCannonDamage"),
                current?Number(e,"mortarShots"):0,current?Number(e,"railgunShots"):0,current?Number(e,"nextMortarTick"):1,current?Number(e,"nextRailgunTick"):1,
                current?Number(e,"mortarDamage"):LastStandUpgradeCatalog.BaseMortarDamage,current?Number(e,"railgunDamage"):LastStandUpgradeCatalog.BaseRailgunDamage,loadout,combatResearch,combat);
            string economy=schema==LastStandShopCheckpoint.LegacyVersion?LastStandUpgradeCatalog.LegacyEconomyVersion:Text(s,"economyVersion");
            var shop=new LastStandShopCheckpoint(Number(s,"runId"),Number(s,"fitting"),Number(s,"purchaseSequence"),Number(s,"uniqueKills"),
                Number(s,"earnedScrap"),Number(s,"spentScrap"),Number(s,"scrap"),ReadLevels(s["permanentLevels"],true,economy),ReadLevels(s["runPurchases"],false,economy),
                economy,schema==1?Number(s,"earnedScrap"):Number(s,"baseEarnedScrap"),schema==1?0:Number(s,"bonusEarnedScrap"),schema==1?0:Number(s,"incomeRemainder"),schema,
                schema==LastStandShopCheckpoint.Version?Number(s,"tier"):encounter.Tier,
                schema==LastStandShopCheckpoint.Version?Number(s,"rewardWave"):1,schema==LastStandShopCheckpoint.Version?Number(s,"defeatedMask"):0,loadout,combatResearch);
            return new LastStandRunCheckpoint(Number(p,"runId"),encounter,shop,
                profileVersion<6?LastStandRunEdition.LegacyContentVersion:Text(p,"contentVersion"));
        }
    }
}
